from django.apps import AppConfig


class NibaticAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Nibatic_app'
