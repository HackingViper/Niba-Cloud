from django.db import models
from django.utils.text import slugify

class Mon_image(models.Model):
    image = models.ImageField(upload_to="images")
    

class Blog(models.Model):
    name = models.CharField(max_length=50, verbose_name="nom (50 carateres max)")
    image = models.ImageField(upload_to="Projets/images")
    slug = models.SlugField(unique=True, blank=True, null=True)
    description = models.TextField(max_length=100,verbose_name="Description (100 carateres max)")
    
    def __str__(self):
        return f'{self.name}'

    def save(self, *args, **kwargs):
        self.slug = slugify(self.name)
      
        super(Blog, self).save(*args, **kwargs)

class Service(models.Model):
    name = models.CharField(max_length=50, verbose_name="nom (50 carateres max)")
    slug = models.SlugField(unique=True, blank=True, null=True)
    description = models.TextField(max_length=100,verbose_name="Description (100 carateres max)")
    
    def __str__(self):
        return f'{self.name}'

    def save(self, *args, **kwargs):
        self.slug = slugify(self.name)
      
        super(Service, self).save(*args, **kwargs)

class Projet(models.Model):
    name = models.CharField(max_length=50,verbose_name="nom (50 carateres max)")
    slug = models.SlugField(unique=True, blank=True, null=True)
    description = models.TextField(max_length=100,verbose_name="Description (100 carateres max)")
    image = models.ImageField(upload_to="Projets/images")

    def __str__(self):
        return f'{self.name}'

    def save(self, *args, **kwargs):
        self.slug = slugify(self.name)
      
        super(Projet, self).save(*args, **kwargs)
    

class Prise_de_contact(models.Model):
    full_name = models.CharField(max_length=255, verbose_name='Nom complet')
    sujet = models.TextField(max_length=250,verbose_name="sujet (250 carateres max)")
    email = models.EmailField(max_length=254)

    def __str__(self):
        return f'{self.full_name} -- sujet : {self.sujet}'

    class Meta:
        verbose_name = ("Prise_de_contact")
        verbose_name_plural = ("Prise_de_contacts")

class News_letter(models.Model):
    email = models.EmailField(max_length=254, blank=True, null=True)

    def __str__(self):
        return f'{self.email}'
    