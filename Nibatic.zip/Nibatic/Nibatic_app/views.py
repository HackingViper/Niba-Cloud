from django.shortcuts import render
from .models import Blog,News_letter,Mon_image,Projet, Service,Prise_de_contact

def index(request):
    message = ""
    if request.method == "POST":
        full_name = request.POST.get("full_name")
        email = request.POST.get("email")
        sujet = request.POST.get("sujet")
        
        Prise_de_contact.objects.get_or_create(
            full_name=full_name,
            email = email,
            sujet=sujet,    
        )
        message = "Prise de contact envoyée avec success"
    
    if request.method == "GET":
        email = request.GET.get('email')

        News_letter.objects.create(
            email=email,
        
        )
        
        message = "Vous vous etes inscrit à la news letter avec success"
        
    context = {
        "Projets":Projet.objects.all,
        "Services":Service.objects.all,
        "image":Mon_image.objects.first,
        "message":message,
        "Blogs":Blog.objects.all,
    }
    return render(request, 'index.html',context)
