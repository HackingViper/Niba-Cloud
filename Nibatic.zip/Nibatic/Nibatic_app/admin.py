from django.contrib import admin
from .models import Blog,Mon_image,Projet, Service,Prise_de_contact,News_letter


admin.site.register(Blog)
admin.site.register(News_letter)
admin.site.register(Mon_image)
admin.site.register(Projet)
admin.site.register(Service)
admin.site.register(Prise_de_contact)
