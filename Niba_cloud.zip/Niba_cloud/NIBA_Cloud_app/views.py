from django.shortcuts import render,redirect
from .models import section, Dossier
from .forms import SectionForm, UploadformFile,UploadZipForm
import os
from django.http import JsonResponse
from django.conf import settings
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.http import FileResponse
import zipfile
import shutil

def login(request):
    return render(request, "login.html")

def acceuil(request):
    nb_dossier = Dossier.objects.count()
    items_list = Dossier.objects.all().order_by('-date_creation')

    # Nombre d'éléments par page
    items_par_page = 4

    # Utilisez le Paginator
    paginator = Paginator(items_list, items_par_page)

    # Obtenez le numéro de page à partir des paramètres GET ou utilisez la page 1 par défaut
    page = request.GET.get('page', 1)

    try:
        items = paginator.page(page)
    except PageNotAnInteger:
        items = paginator.page(1)
    except EmptyPage:
        items = paginator.page(paginator.num_pages)

    context = {
        'nb_dossier':nb_dossier,
        'items':items_list
    }    
    return render(request, "acceuil.html", context)

def users(request):
    
    return render(request, "users.html")

def parametres(request):
    
    return render(request, "parametres.html")



def ExtractZip(file,slug):
    with zipfile.ZipFile(file, 'r') as zip_ref:
       
        folder_name = os.path.splitext(file.name)[0]
        dir_path = os.path.join(settings.MEDIA_ROOT,'sections', slug.lower()+"/")
        exist_folder = dir_path + folder_name
        if os.path.exists(dir_path):
            if os.path.exists(exist_folder):
                shutil.rmtree(exist_folder)
                zip_ref.extractall(dir_path)
            else:
                zip_ref.extractall(dir_path)
                Dossier.objects.create(folder_name=folder_name,section_name=slug.lower())
        else:
            os.makedirs(dir_path, exist_ok=True)
            zip_ref.extractall(dir_path)
            Dossier.objects.create(folder_name=folder_name,section_name=slug.lower())


def uploadZip(request,section_slug):
    message = ""
    if request.method == 'POST':
        
        formZip = UploadZipForm(request.POST, request.FILES)
        
        if formZip.is_valid():
            
            fichier_zip = formZip.cleaned_data['zip_file']
            ExtractZip(fichier_zip,section_slug)
            link = "/dossier/"+section_slug
            return redirect(link)
                
    else:
        formZip = UploadZipForm()
        message = "Uploading echoue"

    context = {
         "formZip":formZip,
         'section_slug':section_slug,
         'Echecmessage':message
    }

    return render(request, 'uploadZip.html', context)


def dossier(request,slug):
    message =""
    if request.method == 'POST':
        formSection = SectionForm(request.POST)
        if formSection.is_valid():
            thisForm = formSection.save(commit=False)
            nom_section = thisForm.name
            
            directory_path = os.path.join(settings.MEDIA_ROOT,"sections",nom_section.lower())

        # Check if the directory already exists
            if os.path.exists(directory_path):
                return JsonResponse({'error': 'Directory already exists.'}, status=400)

            # Create the directory
            os.makedirs(directory_path)
            
            thisForm = formSection.save()
            link = "/dossier/"+nom_section
            return redirect(link)
        
        
    else:
        formSection = SectionForm()

    
    
   
    section_list = section.objects.all()

    items_list = Dossier.objects.filter(section_name=slug)

    # Nombre d'éléments par page
    items_par_page = 8

    # Utilisez le Paginator
    paginator = Paginator(items_list, items_par_page)

    # Obtenez le numéro de page à partir des paramètres GET ou utilisez la page 1 par défaut
    page = request.GET.get('page', 1)

    try:
        items = paginator.page(page)
    except PageNotAnInteger:
        items = paginator.page(1)
    except EmptyPage:
        items = paginator.page(paginator.num_pages)
    


    context = {
		'section': section_list,
        'formSection': formSection,
        'items': items,
        'message':message,
        'section_slug':slug,
               
		}
    
    return render(request, 'dossier.html', context)


def open_file(request, file_name):
    # Spécifiez le chemin complet du fichier que vous souhaitez ouvrir
    file_path = os.path.join(request.GET.get('directory_path', ''), file_name)

    # Servez le fichier en utilisant FileResponse
    response = FileResponse(open(file_path, 'rb'))
    return response

def uploadFichier(request,section_slug,folder_name):
    
    if request.method == 'POST':
        formFile = UploadformFile(request.POST, request.FILES)
        
        if formFile.is_valid():
            fichier = formFile.cleaned_data['file_name']
            
            dir_path = os.path.join(settings.MEDIA_ROOT,'sections',section_slug,folder_name)+"/"
            print(dir_path)
            
            destination_path = os.path.join('media', dir_path, fichier.name)

            # Enregistrer le fichier dans le dossier spécifié
            with open(destination_path, 'wb') as destination_file:
                for chunk in fichier.chunks():
                    destination_file.write(chunk)
            link = "/fichiers/"+section_slug+"/"+folder_name
            
            return redirect(link)

    else:
        formFile = UploadformFile()

    context = {
        'formFile':formFile,
        'section_slug':section_slug,
        'folder_name':folder_name
    }

    return render(request, 'uploadFichier.html', context)


def fichiers(request,section_slug,folder_name):

    if request.method == 'POST':
        formSection = SectionForm(request.POST)
        if formSection.is_valid():
            thisForm = formSection.save(commit=False)
            nom_section = thisForm.name
            
            directory_path = os.path.join(settings.MEDIA_ROOT,"sections",nom_section.lower())

        # Check if the directory already exists
            if os.path.exists(directory_path):
                return JsonResponse({'error': 'Directory already exists.'}, status=400)

            # Create the directory
            os.makedirs(directory_path)

            thisForm = formSection.save()
            link = "/dossier/"+nom_section
            return redirect(link)
        
        
            
    else:
        formSection = SectionForm()
        
   
    section_list = section.objects.all()
    directory_path = os.path.join(settings.MEDIA_ROOT,"sections",section_slug,folder_name+"/") 

    try:
        # Obtenez la liste des fichiers dans le répertoire
        files = os.listdir(directory_path)
        files = [file for file in files if os.path.isfile(os.path.join(directory_path, file))]
        
    except FileNotFoundError:
        
        files = []

    items_list = files


    # Nombre d'éléments par page
    items_par_page = 8

    # Utilisez le Paginator
    paginator = Paginator(items_list, items_par_page)

    # Obtenez le numéro de page à partir des paramètres GET ou utilisez la page 1 par défaut
    page = request.GET.get('page', 1)

    try:
        items = paginator.page(page)
    except PageNotAnInteger:
        items = paginator.page(1)
    except EmptyPage:
        items = paginator.page(paginator.num_pages)
    context = {
        'items': items,
        'directory_path':directory_path,
        'section': section_list,
        'formSection': formSection,
        'section_slug':section_slug,
        'folder_name':folder_name 
    }
    return render(request, 'fichiers.html', context)

def searchDossier(request,section_slug):
    search_term = request.GET.get('requete')
    results = Dossier.objects.filter(section_name =section_slug ,folder_name__icontains=search_term)
    
    data = [{'dossier': result.folder_name, 'section_name':result.section_name} for result in results]
   
    return JsonResponse(data, safe=False)

def searchFile(request,section_slug,folder_name):
    search_term = request.GET.get('requete')

    directory_path = os.path.join(settings.MEDIA_ROOT,"sections",section_slug,folder_name+"/") 

    try:
        # Obtenez la liste des fichiers dans le répertoire
        data = os.listdir(directory_path)
        data = [file for file in data if os.path.isfile(os.path.join(directory_path, file))]
        
    except FileNotFoundError:
        
        data = []

   
    return JsonResponse(data, safe=False)


