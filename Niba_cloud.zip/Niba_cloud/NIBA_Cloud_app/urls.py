from django.urls import path
from . import views


urlpatterns = [
    path("", views.login, name="login"),
    path("acceuil", views.acceuil, name="acceuil"),
    path("dossier/<str:slug>/", views.dossier, name="dossier"),
    path("fichiers/<str:section_slug>/<str:folder_name>/", views.fichiers, name="fichiers"),
    path("users", views.users, name="users"),
    path("parametres", views.parametres, name="parametres"),
    path("open_file/<str:file_name>/", views.open_file, name="open_file"),
    path("uploadZip/<str:section_slug>/", views.uploadZip, name="uploadZip"),
    path("searchDossier/<str:section_slug>/", views.searchDossier, name="searchDossier"),
    path("searchFile/<str:section_slug>/<str:folder_name>/", views.searchFile, name="searchFile"),
    path("uploadFichier/<str:section_slug>/<str:folder_name>/", views.uploadFichier, name="uploadFichier"),
]