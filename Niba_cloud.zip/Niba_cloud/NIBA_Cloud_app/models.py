from django.db import models
from django.utils.text import slugify

class section(models.Model):
    name = models.CharField(max_length=200)
    slug = models.SlugField(unique=True, blank=True, null=True)

    def __str__(self):
        return self.name
    
    def save(self, *args, **kwargs):
        self.slug = slugify(self.name)
        super(section, self).save(*args, **kwargs)

class Dossier(models.Model):
    section_name = models.CharField(max_length=255)
    folder_name = models.CharField(max_length=255)
    date_creation = models.DateTimeField(auto_now_add=True,blank=True, null=True)

    def __str__(self):
        return self.folder_name
    
    class Meta:
        ordering = ['-date_creation']
    
class fichier(models.Model):
    
    dossier_name = models.CharField(max_length=200)
    section_name = models.ForeignKey(section, on_delete=models.CASCADE, related_name="section_group")   
    fichier = models.FileField(upload_to=f'{dossier_name}/')
    date_creation = models.DateTimeField(auto_now_add=True,blank=True, null=True)

    def __str__(self):
        return self.dossier_name
    
    class Meta:
        ordering = ['-date_creation']

class UploadedFile(models.Model):
    zip_file = models.FileField(upload_to='uploaded_zips/')
