from django.forms import ModelForm
from django import forms
from .models import section


class SectionForm(ModelForm):
 
    class Meta:
        model = section
        fields = ['name']

class UploadformFile(forms.Form):
    file_name = forms.FileField()


class UploadZipForm(forms.Form):
    zip_file = forms.FileField()

    