from django.contrib import admin
from NIBA_Cloud_app.models import section,Dossier,fichier


admin.site.register(section)
admin.site.register(Dossier)
admin.site.register(fichier)

